package com.example.calc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;

public class MainActivity extends AppCompatActivity {

    public String exp = "";
    public TextView t1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(R.layout.activity_main);
        t1=   (TextView) findViewById(R.id.tv1);

    }

    @Override
    public void setContentView(View view) {
        super.setContentView(view);
        requestWindowFeature(Window.FEATURE_NO_TITLE);//will hide the title
        getSupportActionBar().hide();
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(R.layout.activity_main);
    }

    public void fun1(View view) {
        exp += "1";
        t1.setText(exp);

    }
    public void fun2(View view) {
        exp += "2";
        t1.setText(exp);

    }
    public void fun3(View view) {
        exp += "3";
        t1.setText(exp);

    }
    public void fun4(View view) {
        exp += "4";
        t1.setText(exp);

    }
    public void fun5(View view) {
        exp += "5";
        t1.setText(exp);

    }
    public void fun6(View view) {
        exp += "6";
        t1.setText(exp);

    }
    public void fun7(View view) {
        exp += "7";
        t1.setText(exp);

    }
    public void fun8(View view) {
        exp += "8";
        t1.setText(exp);

    }
    public void fun9(View view) {
        exp += "9";
        t1.setText(exp);

    }
    public void fun0(View view) {
        exp += "0";
        t1.setText(exp);

    }
    public void plus(View view) {
        exp += "+";
        t1.setText(exp);

    }
    public void minus(View view) {
        exp += "-";
        t1.setText(exp);

    }
    public void mul(View view) {
        exp += "*";
        t1.setText(exp);

    }
    public void div(View view) {
        exp += "/";
        t1.setText(exp);

    }
    public void clr(View view) {
        exp = "";
        t1.setText(exp);

    }

    public void openactivity(){
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }
    public void equal(View view) {
        String sub =(exp.substring(Math.max(exp.length() - 2, 0)));
        if (exp.equals("7777")){
            openactivity();
        }
        if( (exp.substring(exp.length()-1).equals("+")) | (exp.substring(exp.length()-1).equals("-")) | (exp.substring(exp.length()-1).equals("*")) | (exp.substring(exp.length()-1).equals("/")) ){
            Toast.makeText(this, "last sign can not"+ (exp.substring(exp.length()-1)), Toast.LENGTH_SHORT).show();

        }

        else if(  sub.equals("/0")  )
        {
            t1.setText("undefined");
        }
        else {
            Expression ex = new ExpressionBuilder(exp).build();

            double res = ex.evaluate();
            String s1 = Double.toString(res);
            t1.setText(exp + "\n" + s1);
        }

    }

}