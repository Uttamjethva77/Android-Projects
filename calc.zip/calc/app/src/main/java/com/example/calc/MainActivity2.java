package com.example.calc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    public RadioButton rb1, rb2, rb3, rb4;
    public CheckBox cb1;
    public Switch sw1;
    public Spinner sp1;
    public TextView tv1;
    public String uttam = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        rb1 = (RadioButton) findViewById(R.id.rb1);
        rb2 = (RadioButton) findViewById(R.id.rb2);
        rb3 = (RadioButton) findViewById(R.id.rb3);
        rb4 = (RadioButton) findViewById(R.id.rb4);

        cb1 = (CheckBox) findViewById(R.id.cb1);
        sw1 = (Switch) findViewById(R.id.sw1);
        sp1 = (Spinner) findViewById(R.id.sp1);
        tv1 = (TextView) findViewById(R.id.tv1);
        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                uttam += sp1.getSelectedItem().toString();
                tv1.setText(uttam);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            //if need code write here
            }
        });

    }


    public void fun1(View view) {
        if (rb1.isChecked()) {uttam += "rb1";}

        if (rb2.isChecked()) {uttam += "rgb1";}
        else if (rb3.isChecked()) {uttam += "rgb2";}
        else {uttam += "rgb3";}

        if (cb1.isChecked()){uttam += "cb1";}
        if (sw1.isChecked()){uttam += "sw1";}
        tv1.setText(uttam);
    }
}