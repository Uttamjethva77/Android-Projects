package com.example.dayandnight;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button day, night;
        final RelativeLayout rel;
        day = findViewById(R.id.bt1);
        night = findViewById(R.id.bt2);
        rel = findViewById(R.id.rl1);
        day.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { rel.setBackgroundResource(androidx.cardview.R.color.cardview_light_background);

            }
        });
        night.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rel.setBackgroundResource(com.google.android.material.R.color.design_default_color_primary_dark);
            }
        });
    }
}