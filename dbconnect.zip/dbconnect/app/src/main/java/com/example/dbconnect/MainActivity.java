package com.example.dbconnect;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public ceddatabase o1 = new ceddatabase(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void fun2(View view) {
        TextView t1 = (TextView) findViewById(R.id.tv1);
        String str = "";
        Cursor c1 = o1.selectData();
        if(c1!=null && c1.getCount()>0){
            c1.moveToFirst();
            do{
                String s1 = c1.getString(0);
                String s2 = c1.getString(1);
                String s3 = c1.getString(2);
                String s4 = c1.getString(3);
                str += s1+" "+s2+" "+s3+" "+s4+"\n";
            }while (c1.moveToNext());
            t1.setText(str);



        }
    }
    public void openNewActivity5() {
        Intent intent = new Intent(this, loginactivity.class);
        startActivity(intent);
    }
    public void fun1(View view) {
        EditText e1 = (EditText) findViewById(R.id.e1);
        EditText e2 = (EditText) findViewById(R.id.e2);
        EditText e3 = (EditText) findViewById(R.id.e3);
        String s1 = e1.getText().toString();
        String s2 = e2.getText().toString();
        String s3 = e3.getText().toString();
        if((!s1.equals(""))&&(!s2.equals(""))&&(!s3.equals(""))) {
            if (o1.adddata(s1, s2, s3)) {
                Toast.makeText(this, "Data inserted", Toast.LENGTH_LONG).show();
                openNewActivity5();
            } else {
                Toast.makeText(this, "Error", Toast.LENGTH_LONG).show();
            }
        }
        else{
            Toast.makeText(this, "Fields can't be empty", Toast.LENGTH_LONG).show();
        }
        }


    }
