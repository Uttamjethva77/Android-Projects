package com.example.dbconnect;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;

public class ceddatabase extends SQLiteOpenHelper {

    public static String Database = "sample";
    public static String Table1 = "stud";
    public static String Col_1 = "id";
    public static String Col_2 = "name";
    public static String Col_3 = "branch";
    public static String Col_4 = "marks";
    public ceddatabase(@Nullable Context context){
        super(context,Database,null,1);
    }
    @Override
    public void onCreate(SQLiteDatabase db){
        String sql = "create table " + Table1 + "(id integer " +
                "primary key autoincrement, name text, branch text,"+
                "marks integer )";
        db.execSQL(sql);
    }
    @Override
    public  void onUpgrade (SQLiteDatabase db, int i, int i1){
        db.execSQL("drop table "+Table1);
        onCreate(db);
    }
    public boolean adddata( String s1, String s2, String s3){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues c1 = new ContentValues();
        c1.put(Col_2,s1);
        c1.put(Col_3,s2);
        c1.put(Col_4,s3);
        long res = db.insert(Table1,null,c1);
        return (res==-1)?false:true;
    }
    public Cursor selectData(){
        SQLiteDatabase db = getReadableDatabase();
        return db.query(Table1,null,null,null,null,null,null);
    }
}
