package com.example.dbconnect;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class loginactivity extends AppCompatActivity {
    public ceddatabase o1 = new ceddatabase(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginactivity);
    }

    public void fun1(View view) {
        EditText e1 = (EditText) findViewById(R.id.e1);
        EditText e2 = (EditText) findViewById(R.id.e2);
        String s1 = e1.getText().toString();
        String s2 = e2.getText().toString();
        Cursor c1 = o1.selectData();
        if (c1 != null && c1.getCount() > 0) {
            c1.moveToLast()  ;

            String s3 = c1.getString(1);

            String s4 = c1.getString(3);

            if (s2.equals(s4) && s3.equals(s1)) {
                Toast.makeText(this, "Login Success", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, s3, Toast.LENGTH_LONG).show();
            }


        }
    }
}
