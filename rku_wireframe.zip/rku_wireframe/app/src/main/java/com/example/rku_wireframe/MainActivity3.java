package com.example.rku_wireframe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);//will hide the title
        getSupportActionBar().hide(); //hide the title bar
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
    }
    public void openNewActivity5() {
        Intent intent = new Intent(this, MainActivity4.class);
        startActivity(intent);
    }

    public void btn2(View view) {
        openNewActivity5();
    }
}