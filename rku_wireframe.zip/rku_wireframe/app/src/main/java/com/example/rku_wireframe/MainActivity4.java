package com.example.rku_wireframe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

public class MainActivity4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);//will hide the title
        getSupportActionBar().hide(); //hide the title bar
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
    }
    int counter = 0;

    @Override
    public void onBackPressed() {
        counter++;
        if (counter==2){
            super.onBackPressed();
        }
        else{
            Toast.makeText(this, "press back again to exit", Toast.LENGTH_SHORT).show();
        }

    }


    public void btn3(View view) {
        this.onBackPressed();
    }
}